# Code Citations

## License: unknown
https://github.com/ronald1512/Proyecto-Django/tree/f4011e6e145d16fcb0e003884ee383184199c44a/Proyecto-Django/Proyecto1/settings.py

```
],
            'APP_DIRS': True,
            'OPTIONS': {
                'context_processors': [
                    'django.template.context_processors.debug',
                    'django.template.context_processors.request',
                    'django.contrib.auth.context_processors.auth',
                    'django.contrib.
```


## License: unknown
https://github.com/xmyth/portal/tree/6904acd9e5667bd2db4e1b2d0b5c0d399d4bf898/portal/settings.py

```
True,
            'OPTIONS': {
                'context_processors': [
                    'django.template.context_processors.debug',
                    'django.template.context_processors.request',
                    'django.contrib.auth.context_processors.auth',
                    'django.contrib.messages.context_processors.messages'
```


## License: unknown
https://github.com/surinkwon/TIL/tree/d7c57e02131cc5347c5310388ad52049245cc128/django/%EC%9E%A5%EA%B3%A0%20%EC%9D%BC%EA%B8%B0%28Django%20Diary%29.md

```
'django.template.context_processors.debug',
                    'django.template.context_processors.request',
                    'django.contrib.auth.context_processors.auth',
                    'django.contrib.messages.context_processors.messages',
                ],
            },
        },
    ]
    ```

3
```




Domain Name: sc22j4s.pythonanywhere.com

Admin login details
username: sc22j4s
password: admin
email: sc22j4s@leeds.ac.uk

---

Requirements:

requests
pandas

---
 


